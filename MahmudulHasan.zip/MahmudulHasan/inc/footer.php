 <style>
 .footeroption {
  background: none repeat scroll 0 0 #292929;
  color: #FFFFFF;
  font-family: "Times New Roman",Times,serif;
  padding: 20px;
  text-align: center;
 
}
 </style>
 
</section>
<section class="footeroption">
		<h2><?php echo "<p>www.web.com</p>"; ?></h2>
	</section>
</div>
</body>
</html>