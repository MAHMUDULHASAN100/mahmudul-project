 </section>
<section class="footeroption">
		<h2><?php echo "www.web.com"; ?></h2>
	</section>
</div>
</body>
</html>